The .cpp has been built already. If SDL is linked correctly, then you can simply execute by running the command

./Josephus [N] [K]
where N and K are integers
